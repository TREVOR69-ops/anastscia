-- filename: 
-- version: luajit2
-- line: [0, 0] id: 0
local r0_0 = require("lib.samp.events")
local r1_0 = false
local r2_0 = 0
function r0_0.onSendPlayerSync(r0_3)
  -- line: [0, 0] id: 3
  if r1_0 then
    r0_3.weapon = 0
  end
end
function main()
  -- line: [0, 0] id: 1
  -- notice: unreachable block#9
  while not isSampAvailable() do
    -- LOOP
    wait(100)
  end
  sampRegisterChatCommand("trevorveh", function(r0_2)
    -- line: [0, 0] id: 2
    local r1_2 = r1_0
    r1_0 = not r0_2
    r0_2 = tonumber(r0_2)
    if r1_0 and r0_2 and 0 < r0_2 then
      uv1 = r0_2
    end
  end)
  while true do
    -- LOOP
    wait(uv1)
    if r1_0 then
      for r3_1 = 0, 250, 1 do
        if sampIsPlayerConnected(r3_1) then
          sampSendChat("/veh Andromada " .. r3_1 .. " 5   9991")
          printStringNow("~b~ANASTSCIA LUVS U " .. r3_1, uv1)
          wait(uv1)
        end
      end
    end
  end
end