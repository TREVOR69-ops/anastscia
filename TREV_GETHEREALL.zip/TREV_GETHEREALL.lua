﻿local var_0_0 = require("lib.samp.events")
local var_0_1 = false
local var_0_2 = 0

function var_0_0.onSendPlayerSync(arg_1_0)
	if var_0_1 then
		arg_1_0.weapon = 0
	end
end

function main()
	while not isSampAvailable() do
		wait(100)
	end

	sampRegisterChatCommand("trevorgethere", function(arg_3_0)
		var_0_1 = not var_0_1
		arg_3_0 = tonumber(arg_3_0)

		if var_0_1 and arg_3_0 and arg_3_0 > 0 then
			uv1 = arg_3_0
		end
	end)

	while true do
		wait(uv1)

		if var_0_1 then
			for iter_2_0 = 0, 250 do
				if sampIsPlayerConnected(iter_2_0) then
					sampSendChat("/gethere " .. iter_2_0 .. " trevy is here")
					printStringNow("~r~TREVY LUVS U - HILA  " .. iter_2_0, uv1)
					wait(uv1)
				end
			end
		end
	end
end
