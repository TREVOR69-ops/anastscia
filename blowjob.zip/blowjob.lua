script_author('Willy4ka')
script_name('Blowjob mod')
local soundState = require('moonloader').audiostream_state
local ffi = require('ffi')
local inicfg = require 'inicfg'
local directIni = 'blowjob.ini'
local ini = inicfg.load(inicfg.load({
    main = {
        enabled = true,
        animationTime = 20,
        playSound = true,
        price = 200,
        soundVolume = 0.3,
        enabledWanted = false,
        gamepad = false,
    },
}, directIni))
inicfg.save(ini, directIni)

local winmm = ffi.load('winmm.dll')
ffi.cdef[[
    typedef unsigned short WORD;
    typedef unsigned int   UINT;
    typedef unsigned long  DWORD;
    typedef char 		   CHAR;
    typedef unsigned int   UINT_PTR;
    typedef int 		   BOOL;
    typedef UINT	       MMRESULT;
    typedef UINT 		   *LPUINT;
    typedef wchar_t 	   WCHAR;
    typedef struct joyinfo_tag {
        UINT wXpos;
        UINT wYpos;
        UINT wZpos;
        UINT wButtons;
    } JOYINFO, *PJOYINFO, *NPJOYINFO, *LPJOYINFO;
    
    typedef struct joyinfoex_tag {
        DWORD dwSize;
        DWORD dwFlags;
        DWORD dwXpos;
        DWORD dwYpos;
        DWORD dwZpos;
        DWORD dwRpos;
        DWORD dwUpos;
        DWORD dwVpos;
        DWORD dwButtons;
        DWORD dwButtonNumber;
        DWORD dwPOV;
        DWORD dwReserved1;
        DWORD dwReserved2;
    } JOYINFOEX, *PJOYINFOEX, *NPJOYINFOEX, *LPJOYINFOEX;
    UINT joyGetNumDevs(void);
    MMRESULT joyGetPos( 	    UINT uJoyID,  	 LPJOYINFO pji);
    MMRESULT joyGetPosEx( 	    UINT uJoyID,  	 LPJOYINFOEX pji);
]]

local isanim = {}
local sound = nil
if doesFileExist(getWorkingDirectory()..'\\blowjob.mp3') then
    sound = loadAudioStream(getWorkingDirectory()..'\\blowjob.mp3')
end

local JOY_RETURNALL = 0x00000001 or 0x00000002 or 0x00000004 or 0x00000008 or 0x00000010 or 0x00000020 or 0x00000040 or 0x00000080

local joyinfo = ffi.new("JOYINFO");
local joyinfoex	= ffi.new("JOYINFOEX");
local nums = {-1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};
if ini.main.gamepad then
    joyinfoex.dwSize   = ffi.sizeof(joyinfoex);
    joyinfoex.dwFlags  = JOY_RETURNALL;
end
function main()
    while not isPlayerPlaying(PLAYER_HANDLE) do wait(100) end
    if winmm == nil or winmm == false then
        thisScript():unload()
    end
    if not ini.main.enabled then return thisScript():unload() end
    local function start(ped)
        local pedtype = getPedType(ped)
        if pedtype == 22 or pedtype == 5 then
            wait(100)
            if getPlayerMoney(PLAYER_HANDLE) >= ini.main.price then
                taskPause(PLAYER_PED, 1000)
                taskPause(ped, 1000)
                wait(300)
                Blowjob(ped, 'Stand', ini.main.animationTime)
                Blowjob(PLAYER_PED, 'Stand', ini.main.animationTime)
            else
                printString(string.format("no money (%d)", ini.main.price), 1000)
            end
        end
    end
    while true do
        wait(0)
        if isCharInAnyCar(PLAYER_PED) and not isCharInAnyBoat(PLAYER_PED) and not isCharInAnyHeli(PLAYER_PED) and not isCharInAnyPlane(PLAYER_PED) and not isCharInAnyTrain(PLAYER_PED) and not isCharInAnyPoliceVehicle(PLAYER_PED) and not isCharOnAnyBike(PLAYER_PED) then
            local veh = storeCarCharIsInNoSave(PLAYER_PED)
            local passengers = select(2, getNumberOfPassengers(veh))
            if passengers > 0 then
                local seatFree = isCarPassengerSeatFree(veh, 0)
                if not seatFree then
                    local ped = getCharInCarPassengerSeat(veh, 0)
                    local pedtype = getPedType(ped)
                    if pedtype == 22 then
                        if isCharInCar(ped, veh) then
                            if not isanim[ped] then
                                if getPlayerMoney(PLAYER_HANDLE) >= ini.main.price then
                                    wait(1500)
                                    isanim[ped] = true
                                    Blowjob(ped, 'Car', ini.main.animationTime, true, veh)
                                    Blowjob(PLAYER_PED, 'Car', ini.main.animationTime, true)
                                end
                            end
                        end
                    end
                end
            end
        elseif isCharOnFoot(PLAYER_PED) then
            if isPcUsingJoypad() and ini.main.gamepad then
                if joyinfoex.dwPOV == 27000 then
                    local targeting = isPlayerTargettingAnything(PLAYER_HANDLE)
                    if targeting then
                        for k, ped in pairs(getAllChars()) do
                            if ped ~= PLAYER_PED then
                                if isPlayerTargettingChar(PLAYER_HANDLE, ped) then
                                    start(ped)
                                end
                            end
                        end
                    else
                        local dist = 1000
                        local bped = -1
                        for k, ped in pairs(getAllChars()) do
                            local pedType = getPedType(ped)
                            if ped ~= PLAYER_PED and (pedType == 22 or pedType == 5) and isCharOnFoot(ped) then
                                local myPos = {getCharCoordinates(PLAYER_PED)}
                                local pedPos = {getCharCoordinates(ped)}
                                local distance =  getDistanceBetweenCoords3d(myPos[1], myPos[2], myPos[3], pedPos[1], pedPos[2], pedPos[3])
                                if distance < dist then dist = distance bped = ped end
                            end
                        end
                        start(bped)
                    end
                end
            else
                if wasKeyPressed(0x5A) then
                    local tresult, tped = getCharPlayerIsTargeting(PLAYER_HANDLE)
                    if tresult then
                        start(tped)
                    else
                        local dist = 1000
                        local bped = -1
                        for k, ped in pairs(getAllChars()) do
                            local pedType = getPedType(ped)
                            if ped ~= PLAYER_PED and (pedType == 22 or pedType == 5) and isCharOnFoot(ped) then
                                local myPos = {getCharCoordinates(PLAYER_PED)}
                                local pedPos = {getCharCoordinates(ped)}
                                local distance =  getDistanceBetweenCoords3d(myPos[1], myPos[2], myPos[3], pedPos[1], pedPos[2], pedPos[3])
                                if distance < dist then dist = distance bped = ped end
                            end
                        end
                        start(bped)
                    end
                end
            end
        end
    end
end
lua_thread.create(function ()
    while true do
        wait(0)
        if isPlayerPlaying(PLAYER_HANDLE) and ini.main.gamepad then
            local bDev1Attached = winmm.joyGetPos(0, joyinfo) ~= 178
            local wDeviceID = nil
            if bDev1Attached then wDeviceID = bDev1Attached end
            if wDeviceID then
                for i = 1, #nums do
                    winmm.joyGetPosEx(nums[i], joyinfoex);
                end
            end
        end
    end
end)

function Blowjob(ped,animation, time, incar, veh)
    local file = 'blowjobz'
    lua_thread.create(function ()
        local function play(anim)
            if file ~= "PED" then
                requestAnimation(file)
                loadAllModelsNow()
            end
            taskPlayAnim(ped,anim,file,4.1,false,false,false,false,-1)
            if file ~= "PED" then
                removeAnimation(file)
            end
        end
        local _, x, y, z =  getCoordinatesInFrontOfChar(PLAYER_PED, 1.0)
        if not incar and ped ~= PLAYER_PED then
            local mypos = {getCharCoordinates(PLAYER_PED)}
            setHeadingToPosition(ped, mypos[1], mypos[2])
            setCharCoordinates(ped, x, y, z-1)
        end
        play('BJ_'..animation..'_Start_'..(ped == PLAYER_PED and 'P' or 'W'))
        while isCharPlayingAnim(ped, 'BJ_'..animation..'_Start_'..(ped == PLAYER_PED and 'P' or 'W')) do wait(0) end
        local start = os.clock()
        if sound ~= nil then
            local state = getAudioStreamState(sound)
            if state == 1 then
                setAudioStreamState(sound, soundState.STOP)
            end
            if ini.main.playSound then
                setAudioStreamState(sound, soundState.PLAY)
                setAudioStreamVolume(sound, ini.main.soundVolume)
                setAudioStreamLooped(sound, true)
            end
        end
        while os.clock() <= start+time do
            wait(0)
            if not incar and ped ~= PLAYER_PED then
                local mypos = {getCharCoordinates(PLAYER_PED)}
                setHeadingToPosition(ped, mypos[1], mypos[2])
                setCharCoordinates(ped, x, y, z-1)
            end
            if wasKeyPressed(0x58) or joyinfoex.dwPOV == 9000 then
                setAudioStreamLooped(sound, false)
                setAudioStreamState(sound, soundState.STOP)
                break
            end
            if ini.main.enabledWanted then
                for k, p_ped in pairs(getAllChars()) do
                    if getPedType(p_ped) == 6 then
                        local myPos = {getCharCoordinates(PLAYER_PED)}
                        local pedPos = {getCharCoordinates(p_ped)}
                        if getDistanceBetweenCoords3d(myPos[1], myPos[2], myPos[3], pedPos[1], pedPos[2], pedPos[3]) <= 10 then
                            local result, level = storeWantedLevel(PLAYER_HANDLE)
                            if level == 0 then
                                alterWantedLevel(PLAYER_HANDLE, 1)
                                break
                            end
                        end
                    end
                end
            end
            play('BJ_'..animation..'_Loop_'..(ped == PLAYER_PED and 'P' or 'W'))
        end
        if sound ~= nil then
            setAudioStreamLooped(sound, false)
            setAudioStreamState(sound, soundState.STOP)
        end
        play('BJ_'..animation..'_End_'..(ped == PLAYER_PED and 'P' or 'W'))
        wait(100)

        while isCharPlayingAnim(ped, 'BJ_'..animation..'_End_'..(ped == PLAYER_PED and 'P' or 'W')) do wait(0) end
        if ped == PLAYER_PED then
            givePlayerMoney(PLAYER_HANDLE, -ini.main.price)
            setIntStat(33, getIntStat(33)+ini.main.price)
            setIntStat(190, getIntStat(190)+1)
        end
        if veh ~= nil then
            taskLeaveCar(ped, veh)
        end
    end)
end
function getCoordinatesInFrontOfChar(handle, distance)
    if not doesCharExist(handle) then return false end
    local atX, atY, atZ = getCharCoordinates(handle)
    local angle = getCharHeading(handle)
    atX = atX + (distance * math.sin(math.rad(-angle)))
    atY = atY + (distance * math.cos(math.rad(-angle)))
    return true, atX, atY, atZ
end

function setHeadingToPosition(ped, x, y)
    if isCharInAnyCar(ped) then
        local mx, my, mz = getCarCoordinates(storeCarCharIsInNoSave(ped))
        local angle = getHeadingFromVector2d((x - mx), (y - my))
        setCarHeading(storeCarCharIsInNoSave(ped), angle)
    else
        local mx, my, mz = getCharCoordinates(ped)
        local angle = getHeadingFromVector2d((x - mx), (y - my))
        setCharHeading(ped, angle)
    end
end